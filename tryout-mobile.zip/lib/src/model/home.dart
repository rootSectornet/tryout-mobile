class HomeModel {
  bool isloading = false;
  bool isSuccess = false;
  int idPaket = 0;
  String namaPaket = "";
  bool isPondok = false;
  int jenjang = 0;
  String namaJenjang = "";
  String nama = "";
  String picture = "";
}
