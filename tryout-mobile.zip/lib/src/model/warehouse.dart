class WarehouseMod{
  int id;
  String name;
  WarehouseMod(this.id,this.name);
}