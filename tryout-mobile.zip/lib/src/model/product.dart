class Product{
  int id;
  String nama;
  int stock;
  Product(this.id,this.nama,this.stock);
}