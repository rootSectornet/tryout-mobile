// ignore: unused_import
import 'package:flutter/material.dart';
import 'package:TesUjian/src/response/detailpembelian.dart';
import 'package:TesUjian/src/response/detailpenjualan.dart';

class DetailModel {
  bool isloading = false;
  bool isSuccess = false;
  DetailPembelian detailPembelian = new DetailPembelian();
  DetailPenjualan detailPenjualan = new DetailPenjualan();
}
