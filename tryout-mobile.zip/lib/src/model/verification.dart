import 'package:TesUjian/src/response/verifications.dart';

class VerificationModel {
  bool isloading = false;
  bool isSuccess = false;
  String code = "";
  VerifiyResponse verifiyResponse;
}
